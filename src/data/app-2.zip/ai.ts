import { GoogleGenAI, FunctionDeclaration, Type } from "@google/genai";
import { ALL_REGIONS_DATA, PHASE_RULES, SLOT_LABELS, ROUTE_STEPS_DATA, AGENDA_ITEMS } from "./data";
import type { PhaseRule, RegionData } from "./data";

export const initGenAI = () => {
  let apiKey = '';
  try {
    // Attempt to access process.env.API_KEY directly.
    apiKey = process.env.API_KEY;
  } catch (e) {
    console.warn("Could not access process.env.API_KEY directly.");
  }
  return new GoogleGenAI({ apiKey: apiKey || '' });
};

// --- RAG IMPLEMENTATION ---
// Simple keyword-based retrieval for client-side demo
export const findRelevantKnowledge = (query: string): string => {
    if (!query) return "";
    
    const lowerQuery = query.toLowerCase();
    const relevantSteps = ROUTE_STEPS_DATA.filter(step => {
        return step.short_title.toLowerCase().includes(lowerQuery) || 
               step.long_title.toLowerCase().includes(lowerQuery) || 
               step.description.toLowerCase().includes(lowerQuery);
    });

    if (relevantSteps.length === 0) return "";

    return `\nRELEVANTE KENNISBANK ARTIKELEN (Gebruik indien van toepassing op de vraag):\n` + 
           relevantSteps.map(s => `- ${s.short_title}: ${s.long_title}. ${s.description}`).join("\n");
};


export const journeyTool: FunctionDeclaration = {
  name: "updateJourneyState",
  description: "Call this function whenever the user provides information that fills a slot or when the conversation should move to the next phase.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      extracted_slots: {
        type: Type.OBJECT,
        description: "Information extracted from user input.",
        nullable: true,
        properties: {
          school_type: { type: Type.STRING, description: "PO, VO, or MBO" },
          role_interest: { type: Type.STRING },
          credential_goal: { type: Type.STRING },
          admission_requirements: { type: Type.STRING },
          duration_info: { type: Type.STRING },
          costs_info: { type: Type.STRING },
          salary_info: { type: Type.STRING },
          region_preference: { type: Type.STRING },
          next_step: { type: Type.STRING },
        }
      },
      suggest_phase_transition: {
        type: Type.STRING,
        description: "The ID of the phase to move to next. ONLY suggest if all required slots for current phase are filled.",
        nullable: true,
        enum: ["interesse", "orientatie", "beslissing", "matching", "voorbereiding"]
      }
    }
  }
};

export const getSystemInstruction = (context: 'WIDGET' | 'STUDIO', userData?: any, currentPhaseId?: string, filledSlots: any = {}, ragContext: string = "") => {
  
  // Dynamic Region Data
  let regionData: RegionData | undefined;
  if (userData?.region) {
      // Try to find matching region by name or slug
      regionData = ALL_REGIONS_DATA.find(r => r.title === userData.region || r.slug === userData.region);
  } 
  // Fallback to Rotterdam if no region found (or default for widget)
  if (!regionData) regionData = ALL_REGIONS_DATA.find(r => r.slug === 'onderwijsloket-rotterdam');

  const regionTitle = regionData ? regionData.title : "DoorAi";
  const regionEmail = regionData?.email || "info@onderwijs.nl";
  const regionCities = regionData?.cities_municipalities || "Nederland";

  const baseInstruction = `
    Je bent 'Doortje', de AI-assistent van ${regionTitle}.
    
    DOEL:
    Jouw doel is mensen begeleiden naar een baan in het onderwijs in deze regio: ${regionCities}.
    Je geeft praktische, objectieve informatie. Geen druk, garanties of commerciële bias.
    
    BELEID (BELANGRIJK):
    - Toon begrip en wees geduldig.

    CONTACT DATA:
    - Email: ${regionEmail}
    - Website: ${regionData?.website || ''}
    
    ${ragContext ? ragContext : "Geen specifieke kennisbank artikelen gevonden voor deze vraag, gebruik je algemene kennis."}
  `;

  if (context === 'WIDGET') {
    // Format agenda items for the context
    const agendaSummary = AGENDA_ITEMS.slice(0, 3).map(i => `- ${i.title} (${i.date} ${i.month}, ${i.type})`).join('\n');

    return `${baseInstruction}
      SPECIFIEKE OPDRACHT VOOR DE WIDGET:
      Je beantwoordt vragen van anonieme bezoekers. 
      
      BELANGRIJKSTE REGELS:
      1. HOUD HET KORT: Je antwoorden mogen absoluut NIET langer zijn dan 40-50 woorden.
      2. GEBRUIK LINKS: Verwijs niet alleen met tekst, maar gebruik de onderstaande "HARDE LINKS" in Markdown formaat (bijv [tekst](/link)).
      3. TOON: Wees zacht, aardig en uitnodigend.
      
      HARDE LINKS (Gebruik EXACT deze paden in je markdown links):
      - Voor salaris/subsidies: [Financiën & Subsidies](/finance)
      - Voor zij-instroom info: [Zij-instroom](/route-zijinstroom)
      - Voor deeltijd info: [Deeltijd](/route-deeltijd)
      - Voor PDG/MBO info: [PDG Traject](/route-pdg)
      - Voor evenementen: [De Agenda](/agenda)
      - Voor de check: [Doe de Check](/check)
      - Voor contact: [Contactpagina](/contact)

      ACTUELE AGENDA (Gebruik dit om urgentie te creëren):
      ${agendaSummary}

      VOORBEELDEN:
      User: "Wat verdien ik?"
      Model: "Dat hangt af van je ervaring! Op onze pagina [Financiën & Subsidies](/finance) hebben we alle salarisschalen en subsidies overzichtelijk voor je op een rij gezet."

      User: "Ik twijfel of het iets voor mij is."
      Model: "Dat is heel begrijpelijk. Speciaal daarvoor hebben we de [Onderwijs Check](/check) ontwikkeld. Die duurt maar 1 minuut. Of kom sfeer proeven via [de Agenda](/agenda)!"
      
      User: "Ik heb een hbo diploma."
      Model: "Super! Dan is het [Zij-instroom](/route-zijinstroom) traject wellicht iets voor jou. Je staat dan direct voor de klas met salaris."
    `;
  } else {
    // STUDIO CONTEXT (More detailed, conversational)
    const phaseConfig = PHASE_RULES.find(p => p.code === currentPhaseId) || PHASE_RULES[0];
    
    // Calculate missing slots based on strict rules
    const missingSlots = phaseConfig.required_slots.filter(s => !filledSlots[s]);
    const niceToHaveSlots = phaseConfig.optional_slots.filter(s => !filledSlots[s]);

    let taskInstruction = "";
    if (missingSlots.length > 0) {
        taskInstruction = `CRITIEK: Je MOET de volgende informatie nog achterhalen voordat de gebruiker naar de volgende fase kan: ${missingSlots.map(s => SLOT_LABELS[s]).join(", ")}. Stel gerichte vragen hierover.`;
    } else {
        taskInstruction = `Alle verplichte info voor deze fase is binnen. Je kunt nu optioneel vragen naar: ${niceToHaveSlots.slice(0,2).map(s => SLOT_LABELS[s]).join(", ")} OF voorstellen om naar de volgende fase te gaan als de gebruiker dat wil.`;
    }

    return `${baseInstruction}
      SPECIFIEK VOOR DE PERSOONLIJKE OMGEVING (MIJN OMGEVING):
      Je spreekt met ${userData?.name}. 
      HUIDIGE FASE: ${phaseConfig.title}. 
      DOEL VAN DEZE FASE: ${phaseConfig.description}.
      
      JOUW TAAK: 
      1. Luister goed naar de gebruiker.
      2. Gebruik 'updateJourneyState' als je nieuwe info hoort over: ${Object.keys(SLOT_LABELS).join(", ")}.
      3. ${taskInstruction}
      4. Stel maximaal 1 vervolgvraag per beurt.
      5. Richt je vraag op de grootste progressie in de huidige fase.
      
      Huidige bekende info: ${JSON.stringify(filledSlots)}
    `;
  }
};