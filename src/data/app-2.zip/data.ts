import { 
  Sparkles, 
  Compass, 
  CheckCircle, 
  Users, 
  Briefcase 
} from "lucide-react";

// --- TYPE DEFINITIONS ---
export interface PhaseRule {
  code: string;
  title: string;
  description: string;
  required_slots: string[];
  optional_slots: string[];
}

export interface RegionData {
  id: string;
  title: string;
  email: string | null;
  website: string | null;
  cities_municipalities: string;
  slug: string;
  area?: {
    area_center: { coordinates: number[] };
    area_bounds: { coordinates: number[][][] };
  };
}

// --- 1. PHASE RULES (From phase_detector.rules.json) ---
export const PHASE_RULES: PhaseRule[] = [
    {
      "code": "interesse",
      "title": "Interesseren",
      "description": "Kennismaking met het onderwijs.",
      "required_slots": [],
      "optional_slots": ["role_interest", "credential_goal", "admission_requirements", "duration_info", "costs_info", "salary_info", "region_preference", "next_step"]
    },
    {
      "code": "orientatie",
      "title": "Oriënteren",
      "description": "Welke route past bij mij?",
      "required_slots": ["school_type"],
      "optional_slots": ["role_interest", "credential_goal", "admission_requirements", "duration_info", "costs_info", "salary_info", "region_preference", "next_step"]
    },
    {
      "code": "beslissing",
      "title": "Beslissen",
      "description": "De knoop doorhakken.",
      "required_slots": ["school_type", "role_interest"], // Added role_interest based on logical flow interpretation
      "optional_slots": ["credential_goal", "admission_requirements", "duration_info", "costs_info", "salary_info", "region_preference", "next_step"]
    },
    {
      "code": "matching",
      "title": "Matchen",
      "description": "Werkplek vinden.",
      "required_slots": ["school_type", "credential_goal"], // Enforcing credential goal here
      "optional_slots": ["role_interest", "admission_requirements", "duration_info", "costs_info", "salary_info", "region_preference", "next_step"]
    },
    {
      "code": "voorbereiding",
      "title": "Voorbereiden",
      "description": "Startklaar maken.",
      "required_slots": ["school_type", "next_step"],
      "optional_slots": ["role_interest", "credential_goal", "admission_requirements", "duration_info", "costs_info", "salary_info", "region_preference"]
    }
];

export const SLOT_LABELS: Record<string, string> = {
    school_type: "Onderwijssector (PO/VO/MBO)",
    role_interest: "Gewenste functie/rol",
    credential_goal: "Beoogde bevoegdheid",
    admission_requirements: "Toelatingseisen gecheckt",
    duration_info: "Duur traject besproken",
    costs_info: "Kosten & Financiering",
    salary_info: "Salarisindicatie",
    region_preference: "Regio voorkeur",
    next_step: "Concrete vervolgstap"
};

export const getPhaseIcon = (phaseCode: string) => {
    switch(phaseCode) {
        case 'interesse': return Sparkles;
        case 'orientatie': return Compass;
        case 'beslissing': return CheckCircle;
        case 'matching': return Users;
        case 'voorbereiding': return Briefcase;
        default: return Sparkles;
    }
};

// --- 2. REGIONAL DATA (From Regional Education Desks JSON) ---
// Minified for performance, containing essential fields + geometry
export const ALL_REGIONS_DATA: RegionData[] = [
	{
		"title": "SchoolpleinNoord",
		"email": "info@schoolpleinnoord.nl",
		"cities_municipalities": "Leeuwarden, Sneek, Drachten, Heerenveen, Groningen, Delfzijl...",
		"slug": "schoolpleinnoord",
        "website": "https://schoolpleinnoord.nl/",
		"id": "00028ec1-1c2b-4cd5-ae93-27f51b9af76b",
        "area": { "area_center": { "coordinates": [ 6.166343, 52.973792 ] }, "area_bounds": { "coordinates": [[ [5.65273, 53.318863], [5.471456, 53.235105], [5.405538, 53.178353], [5.380819, 53.073698], [5.411031, 52.946452], [6.156728, 52.66752], [6.6209, 52.670851], [7.041128, 52.630861], [7.216909, 53.000205], [7.104299, 53.306556], [6.885946, 53.439284], [6.31603, 53.410644], [5.872457, 53.391812], [5.65273, 53.318863] ]] } }
	},
    {
		"title": "VOTA",
		"email": "instroommakelaar@vota.nl",
        "website": "https://vota.nl",
		"cities_municipalities": "Enschede, Hengelo, Almelo, Deventer...",
		"slug": "vota",
		"id": "03665f02-af2c-413b-a8d4-433dfc0cdb06",
        "area": { "area_center": { "coordinates": [ 6.637854, 52.247944 ] }, "area_bounds": { "coordinates": [[ [6.701102, 52.487651], [6.34542, 52.444982], [6.168265, 52.364551], [6.076255, 52.273051], [6.515708, 52.033759], [6.984, 52.186414], [7.077384, 52.392216], [6.701102, 52.487651] ]] } }
	},
    {
		"title": "Onderwijsloket Rotterdam",
		"email": "info@onderwijsloketrotterdam.nl",
        "website": "https://onderwijsloketrotterdam.nl/",
		"cities_municipalities": "Rotterdam, Schiedam, Vlaardingen, Capelle a/d IJssel...",
		"slug": "onderwijsloket-rotterdam",
		"id": "3bf5c826-f42b-4e2e-a8af-4fc08088628e",
        "area": { "area_center": { "coordinates": [ 4.478639, 51.948914 ] }, "area_bounds": { "coordinates": [[ [4.31024, 51.904513], [4.321227, 51.869337], [4.466796, 51.862977], [4.595198, 51.907479], [4.63159, 51.915527], [4.621977, 51.980281], [4.540953, 52.000577], [4.53752, 52.032271], [4.448943, 52.004804], [4.411864, 51.946858], [4.31024, 51.904513] ]] } }
	},
    {
        "title": "Onderwijsloket Nijmegen",
        "email": "contact@onderwijsloketnijmegen.nl",
        "website": "https://onderwijsloketnijmegen.nl/",
        "cities_municipalities": "Nijmegen, Lent",
        "slug": "onderwijsloket-nijmegen",
        "id": "10227b38-f279-44aa-8238-addea3cdbbcd",
        "area": { "area_center": { "coordinates": [ 5.815187, 51.816641 ] }, "area_bounds": { "coordinates": [[ [5.934615, 51.941347], [5.76982, 51.9206], [5.489669, 51.908318], [5.563827, 51.817999], [5.817199, 51.657694], [6.059585, 51.860849], [5.934615, 51.941347] ]] } }
    },
    {
        "title": "Liever voor de klas (Amsterdam)",
        "email": "info@lievervoordeklas.nl",
        "website": "https://www.lievervoordeklas.nl",
        "cities_municipalities": "Amsterdam",
        "slug": "liever-voor-de-klas",
        "id": "30ef96c3-51d6-4f8a-8d26-19e2cde189e8",
        "area": { "area_center": { "coordinates": [ 4.856610, 52.347291 ] }, "area_bounds": { "coordinates": [[ [4.738325, 52.428243], [4.727339, 52.29028], [4.885267, 52.28692], [5.004744, 52.338134], [5.01161, 52.38384], [4.897627, 52.428243], [4.738325, 52.428243] ]] } }
    },
    {
        "title": "Flevowijs",
        "email": "contact@flevowijs.nl",
        "website": "https://flevowijs.nl",
        "cities_municipalities": "Almere, Lelystad",
        "slug": "flevowijs",
        "id": "9ef6e554-ab66-48f4-9a2f-a49678f95a5d",
        "area": { "area_center": { "coordinates": [ 5.327123, 52.413196 ] }, "area_bounds": { "coordinates": [[ [5.244841, 52.330317], [5.280546, 52.318566], [5.584044, 52.453512], [5.597777, 52.487811], [5.4989, 52.547979], [5.221495, 52.420024], [5.123991, 52.379804], [5.244841, 52.330317] ]] } }
    },
    {
        "title": "Lesgeven in Zeeland",
        "email": "contact@lesgeveninzeeland.nl",
        "website": "https://lesgeveninzeeland.nl",
        "cities_municipalities": "Middelburg, Vlissingen, Goes, Terneuzen...",
        "slug": "lesgeven-in-zeeland",
        "id": "e8ec0c98-138e-456c-a210-8495ed268de1",
        "area": { "area_center": { "coordinates": [ 3.781135, 51.450278 ] }, "area_bounds": { "coordinates": [[ [3.36283, 51.369698], [3.513892, 51.28732], [3.859962, 51.210816], [4.260963, 51.447649], [4.237617, 51.55707], [4.006932, 51.759661], [3.36283, 51.369698] ]] } }
    },
    {
        "title": "Limburg VO",
        "email": "mverhaegh@ogvo.nl",
        "website": null,
        "cities_municipalities": "Maastricht, Heerlen, Venlo, Roermond...",
        "slug": "limburg-vo",
        "id": "9691e46c-9c3d-4202-846e-28895c3304e6",
        "area": { "area_center": { "coordinates": [ 5.863482, 51.080460 ] }, "area_bounds": { "coordinates": [[ [5.561843, 51.220844], [5.69044, 51.184957], [5.855578, 51.145559], [5.80511, 51.095995], [5.758418, 51.031482], [5.68323, 50.890276], [5.692843, 50.811811], [5.820903, 50.758632], [6.022614, 51.090368], [6.220368, 51.444377], [6.034973, 51.589655], [5.852981, 51.501245], [5.561843, 51.220844] ]] } }
    }
];

// Helper: Convert GeoJSON [Lng, Lat] to Leaflet [Lat, Lng]
export const getLeafletPolygon = (regionSlug: string): [number, number][] => {
    const region = ALL_REGIONS_DATA.find(r => r.slug === regionSlug);
    if (!region || !region.area?.area_bounds?.coordinates[0]) return [];
    
    // GeoJSON is Lng,Lat. Leaflet needs Lat,Lng.
    return region.area.area_bounds.coordinates[0].map((coord: number[]) => [coord[1], coord[0]] as [number, number]); 
};

export const getLeafletCenter = (regionSlug: string): [number, number] => {
    const region = ALL_REGIONS_DATA.find(r => r.slug === regionSlug);
    if (!region || !region.area?.area_center?.coordinates) return [52.1326, 5.2913]; // Default center NL
    return [region.area.area_center.coordinates[1], region.area.area_center.coordinates[0]] as [number, number];
};


// --- 3. ROUTE STEPS (From Route Steps JSON) ---
export const ROUTE_STEPS_DATA = [
	{
		"short_title": "Wo-bachelor",
		"slug": "wo-f",
		"duration_in_months": 36,
		"long_title": "Stroom door naar het primair onderwijs met behulp van specifieke wo-bachelors",
        "description": "Wo-bacheloropleidingen zijn academische studies op het wetenschappelijk niveau van een vakgebied. Er zijn tal van wo-bacheloropleidingen die mogelijk passen bij jouw interesse. Met een wo-bachelor in de sector Gedrag en Maatschappij ben je toelaatbaar tot de universitaire Educatieve Master Primair Onderwijs (EMPO)."
	},
	{
		"short_title": "Hbo-master",
		"slug": "hbom",
		"duration_in_months": 24,
		"long_title": "Verdiep je als tweedegraads leraar en wordt eerstegraads leraar.",
        "description": "Na het behalen van een tweedegraads bevoegdheid (via een hbo-bacheloropleiding of kopopleiding) kun je jouw bevoegdheid uitbreiden tot een eerstegraads bevoegdheid voor datzelfde schoolvak door middel van een hbo-master."
	},
	{
		"short_title": "Mbo-4",
		"slug": "mbo4-b",
		"duration_in_months": 48,
		"long_title": "Stroom door naar een associate degree of hbo-opleiding met behulp van een mbo 4-opleiding",
        "description": "Een mbo 4-opleiding is een middenkaderopleiding. Na een mbo 4-opleiding kun je doorstromen naar een associate degree-opleiding of een hbo-bacheloropleiding."
	},
	{
		"short_title": "PDG",
		"slug": "pdg-a",
		"duration_in_months": 12,
		"long_title": "Word docent in het mbo met behulp van een PDG-traject",
        "description": "Met een pedagogisch-didactisch getuigschrift (PDG), in combinatie met een geschiktheidsverklaring afgegeven door het bevoegd gezag van de mbo-instelling, mag je lesgeven op die mbo-instelling. Je kunt dit getuigschrift halen via een zij-instroomtraject: het PDG-traject."
	},
    {
		"short_title": "Zij-instroom",
		"slug": "ulo-zib",
		"duration_in_months": 12,
		"long_title": "Word eerstegraads leraar met behulp van een zij-instroomtraject",
        "description": "Het traject 'zij-instroom in het beroep' (zib) is een bijzonder opleidingstraject tot een bevoegdheid. Tijdens dit leer-werktraject loop je geen stage, maar sta je direct zelfstandig voor de klas."
	},
    {
		"short_title": "Verkorte pabo",
		"slug": "p-hbo-b",
		"duration_in_months": 24,
		"long_title": "Word leraar in het primair onderwijs met behulp van de verkorte deeltijd pabo",
        "description": "Als je je hbo- of wo-opleiding hebt afgerond, kun je starten aan een verkorte deeltijdvariant van de pabo. Hierbij behaal je in twee tot drie jaar een pabodiploma."
	},
    {
		"short_title": "Kopopleiding",
		"slug": "p-hbo-a",
		"duration_in_months": 12,
		"long_title": "Word tweedegraads leraar met behulp van de kopopleiding",
        "description": "Als je een hbo- of wo-bachelor hebt behaald en als deze voldoende aansluit bij een schoolvak, kun je starten aan de eenjarige kopopleiding. De kopopleiding is het verkorte traject van de tweedegraads lerarenopleiding."
	},
    {
		"short_title": "AD",
		"slug": "ad-a",
		"duration_in_months": 24,
		"long_title": "Word leraarondersteuner met behulp van een associate degree",
        "description": "De associate degree is een tweejarige praktijkgerichte opleiding op hbo-niveau. Als je kiest voor de associate degree Pedagogisch Educatief Professional (AD-PEP) word je opgeleid tot leraarondersteuner."
	},
     {
		"short_title": "Hbo-bachelor",
		"slug": "hbo-b",
		"duration_in_months": 48,
		"long_title": "Word tweedegraads leraar met behulp van deze hbo-opleiding",
        "description": "De opleiding tot tweedegraads leraar in een bepaald schoolvak is een hbo-bacheloropleiding. Tijdens deze opleiding duik je in de vakkennis en de pedagogische en didactische vaardigheden die horen het geven van jouw schoolvak of beroepsprofiel."
	},
    {
		"short_title": "Wo-master",
		"slug": "ulo",
		"duration_in_months": 12,
		"long_title": "Word eerstegraads leraar met behulp van de universitaire lerarenopleiding",
        "description": "Als jouw vooropleiding en eventuele werkervaring voldoende aansluit bij een schoolvak, ben je toelaatbaar tot de universitaire lerarenopleiding (master leraar voorbereidend hoger onderwijs, LVHO)."
	}
];


// --- 4. QUESTIONS & MOCK DATA (Legacy/UI support) ---

export const ROUTE_QUESTIONS = [
    {
		"question": "Op wat voor school zou je willen werken?",
		"id": "3a049db7-70da-43cd-be29-b312dcbcdd1f",
		"sort": 1,
		"answers": [
			{ "id": "a0ccd547", "title": "Basisschool (po)" },
			{ "id": "573c0e1d", "title": "Middelbare school (vo)" },
			{ "id": "5bdbdbef", "title": "Middelbaar beroepsonderwijs (mbo)" },
			{ "id": "c30c2eba", "title": "Hoger onderwijs (ho)" },
			{ "id": "4ca58dfb", "title": "Speciaal onderwijs (so/vso)" },
			{ "id": "2e6b253f", "title": "Volwassenenonderwijs (vavo)" }
		]
	},
	{
		"question": "In wat voor functie ben je geïnteresseerd?",
		"id": "0973fae8-732b-4a9e-b04b-9e02a7eb7b77",
		"sort": 2,
		"answers": [
			{ "id": "869ed3c3", "title": "Leraar" },
			{ "id": "50dbad67", "title": "Onderwijsondersteunend personeel" },
			{ "id": "494c77fc", "title": "Ondersteunend personeel" },
			{ "id": "da036694", "title": "Schoolleiding" },
			{ "id": "f07f61ef", "title": "Middenmanagement" },
			{ "id": "099af0e1", "title": "Instructeur" },
			{ "id": "d2e77721", "title": "Leerlingenzorg" }
		]
	},
    {
		"question": "Wat is het niveau van je hoogst afgeronde opleiding?",
		"id": "ffde53a3-c46f-413c-828f-1d000a0fccea",
		"sort": 3,
		"answers": [
			{ "id": "7cc5adfb", "title": "Geen vooropleiding" },
			{ "id": "351569ce", "title": "Vmbo-kl" },
			{ "id": "8d6292c9", "title": "Vmbo-tl/mavo" },
			{ "id": "5cd49590", "title": "Havo" },
			{ "id": "7808886f", "title": "Vwo" },
			{ "id": "24bf2412", "title": "Mbo 4" },
			{ "id": "e34bed80", "title": "Associate degree" },
			{ "id": "7c5dfe12", "title": "Hbo-bachelor" },
			{ "id": "ed90340f", "title": "Wo-bachelor" },
			{ "id": "823772ea", "title": "Wo-master" }
		]
	},
    {
		"question": "Wat voor lesbevoegdheid of getuigschift wil je halen?",
		"id": "0a9e0eb0-f45c-4069-aee8-e4333061b42b",
		"sort": 4,
		"answers": [
			{ "id": "daa3b054", "title": "Primair onderwijs" },
			{ "id": "f9bd6075", "title": "Tweedegraads bevoegdheid" },
			{ "id": "4967c1d6", "title": "Eerstegraads bevoegdheid" },
			{ "id": "3fdafaff", "title": "PDG" },
            { "id": "179d7cef", "title": "Ongegradeerde bevoegdheid" }
		]
	}
];


// --- MOCK DATA FOR BACKOFFICE ---
export const MOCK_CANDIDATES = [
  { id: "C001", name: "Sanne de Vries", email: "sanne@test.nl", phase: "orientatie", last_active: "2 uur geleden", hitl: false, slots: { school_type: "PO", region_preference: "Rotterdam Centrum" } },
  { id: "C002", name: "Mark Jansen", email: "mark@test.nl", phase: "beslissing", last_active: "1 dag geleden", hitl: true, hitl_reason: "Twijfelt over salaris", slots: { school_type: "VO", role_interest: "Docent Wiskunde", salary_info: "Schaal 10/11?" } },
  { id: "C003", name: "Fatima El Amrani", email: "fatima@test.nl", phase: "matching", last_active: "3 uur geleden", hitl: false, slots: { school_type: "MBO", credential_goal: "PDG", next_step: "Sollicitatiegesprek Zadkine" } },
  { id: "C004", name: "Peter Bakker", email: "peter@test.nl", phase: "interesse", last_active: "5 min geleden", hitl: false, slots: {} },
  { id: "C005", name: "Annet Visser", email: "annet@test.nl", phase: "voorbereiding", last_active: "1 week geleden", hitl: false, slots: { school_type: "PO", admission_requirements: "Voldaan", next_step: "Assessment Pabo" } },
  { id: "C006", name: "Kees van der Meer", email: "kees@test.nl", phase: "orientatie", last_active: "2 dagen geleden", hitl: true, hitl_reason: "Vragen over Zij-instroom subsidie", slots: { school_type: "VO" } },
];

export const REGIONS = ALL_REGIONS_DATA.map(r => r.title);

export const AGENDA_ITEMS = [
  { id: 1, date: "02", month: "APR", title: "Thomas More Hogeschool: Open Avond", loc: "Rotterdam", time: "18:30 - 21:00", type: "Fysiek", link: "https://www.thomasmorehs.nl/open-avond" },
  { id: 2, date: "05", month: "APR", title: "Hogeschool Leiden: Open Dag", loc: "Leiden", time: "10:00 - 14:00", type: "Fysiek", link: "https://www.hsleiden.nl/open-dag" },
  { id: 3, date: "12", month: "APR", title: "Hogeschool Rotterdam: Open Dag", loc: "Rotterdam", time: "10:00 - 15:00", type: "Fysiek", link: "https://www.hogeschoolrotterdam.nl/voorlichting/open-dagen/" },
  { id: 4, date: "16", month: "APR", title: "Inholland Rotterdam: Open Avond", loc: "Rotterdam", time: "18:00 - 20:30", type: "Fysiek", link: "https://www.inholland.nl/open-dagen/" },
  { id: 5, date: "22", month: "MEI", title: "TU Delft: Lerarenopleiding Info", loc: "Delft", time: "19:00 - 21:00", type: "Online/Fysiek", link: "https://www.tudelft.nl/onderwijs/opleidingen/lerarenopleiding" }
];