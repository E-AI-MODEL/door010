import React, { useState, useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";
import ReactMarkdown from "react-markdown";
import { 
  MapPin, 
  ChevronRight, 
  BookOpen, 
  Compass, 
  CheckCircle, 
  Users, 
  Briefcase, 
  Send,
  Sparkles,
  Info,
  Lightbulb, 
  ArrowRight,
  MessageSquare,
  X,
  Lock,
  MessageCircle,
  GraduationCap,
  Euro,
  ArrowLeft,
  Check,
  Calendar,
  Phone,
  Mail,
  HelpCircle,
  LayoutDashboard,
  AlertCircle,
  TrendingUp,
  Search,
  Eye,
  Filter,
  BarChart3,
  Bell,
  BellOff
} from "lucide-react";

import { MapContainer, TileLayer, Polygon, Marker, Popup, useMap } from 'react-leaflet';

import { 
  PHASE_RULES,
  ALL_REGIONS_DATA,
  SLOT_LABELS,
  getPhaseIcon,
  getLeafletPolygon,
  getLeafletCenter,
  ROUTE_QUESTIONS,
  ROUTE_STEPS_DATA,
  MOCK_CANDIDATES, 
  AGENDA_ITEMS
} from "./data";

import type { RegionData } from "./data";

import { 
  initGenAI, 
  journeyTool, 
  getSystemInstruction,
  findRelevantKnowledge
} from "./ai";


// --- Error Boundary ---
class ErrorBoundary extends React.Component<{children: React.ReactNode}, {hasError: boolean, error: any}> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
          <div className="bg-white p-8 rounded-xl shadow-lg border border-red-100 max-w-md w-full">
            <h1 className="text-xl font-bold text-red-600 mb-2">Er is iets misgegaan</h1>
            <p className="text-slate-600 mb-4">De applicatie kon niet laden. Probeer de pagina te verversen.</p>
            <details className="bg-slate-100 p-3 rounded text-xs text-slate-500 overflow-auto max-h-40">
                <summary>Technische details</summary>
                <pre className="mt-2">{this.state.error?.toString()}</pre>
            </details>
            <button 
              onClick={() => window.location.reload()} 
              className="mt-6 w-full bg-rotterdam-green text-white py-2 rounded-lg hover:bg-[#154a48] transition-colors"
            >
              Pagina verversen
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// --- Helper Components ---

// Map Updater to handle dynamic view changes
const MapUpdater = ({ center, zoom }: { center: [number, number], zoom: number }) => {
    const map = useMap();
    useEffect(() => {
        map.setView(center, zoom);
    }, [center, zoom, map]);
    return null;
};

const MessageBubble = ({ role, text, isThinking, compact, onNavigate }: any) => {
  const isUser = role === "user";
  return (
    <div className={`flex w-full ${isUser ? "justify-end" : "justify-start"} ${compact ? 'mb-3' : 'mb-6'}`}>
      <div className={`flex flex-col ${compact ? 'max-w-[90%]' : 'max-w-[85%] sm:max-w-[75%]'} ${isUser ? "items-end" : "items-start"}`}>
        {!compact && (
          <span className={`text-[11px] font-semibold mb-1.5 px-1 ${isUser ? "text-rotterdam-green" : "text-slate-400"}`}>
            {isUser ? "Jij" : "Doortje"}
          </span>
        )}
        <div className={`${compact ? 'px-3 py-2 text-xs' : 'px-5 py-4 text-sm'} shadow-sm leading-relaxed overflow-hidden ${isUser ? "bg-rotterdam-green text-white rounded-2xl rounded-tr-sm" : "bg-white text-slate-700 border border-slate-200 rounded-2xl rounded-tl-sm"}`}>
          {isThinking ? (
            <div className="flex space-x-1 h-4 items-center px-1">
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full typing-dot"></div>
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full typing-dot"></div>
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full typing-dot"></div>
            </div>
          ) : (
            <div className="markdown-content break-words break-all sm:break-normal">
                <ReactMarkdown
                    components={{
                        a: ({ node, ...props }) => {
                            // Check if it's an internal link starting with /
                            if (props.href && props.href.startsWith('/') && onNavigate) {
                                return (
                                    <span 
                                        onClick={() => onNavigate(props.href?.substring(1))}
                                        className="text-rotterdam-green font-bold underline cursor-pointer hover:text-emerald-700"
                                    >
                                        {props.children}
                                    </span>
                                );
                            }
                            // External links
                            return (
                                <a 
                                    {...props} 
                                    target="_blank" 
                                    rel="noopener noreferrer" 
                                    className="text-blue-600 underline hover:text-blue-800"
                                >
                                    {props.children}
                                </a>
                            );
                        }
                    }}
                >
                    {text}
                </ReactMarkdown>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- New Component: Registration Modal (Simplified) ---
const RegistrationModal = ({ onClose }: { onClose: () => void }) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    interest: "Algemene oriëntatie"
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTimeout(() => {
        setSubmitted(true);
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white max-w-lg w-full rounded-2xl shadow-2xl p-8 overflow-y-auto relative">
        
        <button onClick={onClose} className="absolute top-4 right-4 bg-slate-100 p-2 rounded-full hover:bg-slate-200 transition-colors">
            <X className="w-5 h-5 text-slate-500" />
        </button>

          {!submitted ? (
            <>
              <h2 className="text-2xl font-serif font-bold text-rotterdam-green mb-2">Blijf op de hoogte</h2>
              <p className="text-slate-600 text-sm mb-6">Meld je aan voor onze nieuwsbrief of een vrijblijvend oriëntatiegesprek.</p>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Voornaam</label>
                    <input required type="text" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none text-sm" 
                      value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Achternaam</label>
                    <input required type="text" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none text-sm"
                      value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} />
                  </div>
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Emailadres</label>
                   <input required type="email" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none text-sm"
                      value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Telefoonnummer (optioneel)</label>
                   <input type="tel" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none text-sm"
                      value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Ik heb interesse in</label>
                   <select className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none text-sm"
                      value={formData.interest} onChange={e => setFormData({...formData, interest: e.target.value})}>
                      <option>Algemene oriëntatie</option>
                      <option>Zij-instroom traject</option>
                      <option>Vacatures</option>
                      <option>Evenementen</option>
                   </select>
                </div>
                
                <button type="submit" className="w-full mt-6 bg-rotterdam-green hover:bg-[#154a48] text-white font-bold py-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-2">
                   Aanmelden <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center space-y-4 animate-in zoom-in-95 duration-300">
               <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                 <CheckCircle className="w-8 h-8" />
               </div>
               <h3 className="text-xl font-bold text-slate-800">Bedankt voor je aanmelding!</h3>
               <p className="text-sm text-slate-500">We hebben je gegevens ontvangen en nemen zo snel mogelijk contact met je op.</p>
               <button onClick={onClose} className="text-rotterdam-green font-bold text-sm hover:underline">Sluit venster</button>
            </div>
          )}
      </div>
    </div>
  );
};


// --- Route Check Wizard ---

const RouteCheckWizard = ({ onComplete, onCancel }: { onComplete: (data: any) => void, onCancel: () => void }) => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<any>({});
  
  const questions = ROUTE_QUESTIONS.sort((a, b) => a.sort - b.sort);

  const handleSelect = (questionId: string, optionTitle: string) => {
    setAnswers({ ...answers, [questionId]: optionTitle });
    
    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      setStep(step + 1); // Move to result view
    }
  };

  if (step === questions.length) {
    // Result View
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-300">
        <div className="bg-white max-w-lg w-full rounded-2xl shadow-2xl overflow-hidden">
           <div className="bg-rotterdam-green p-8 text-center text-white">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8" />
              </div>
              <h2 className="text-2xl font-serif font-bold mb-2">Goed nieuws!</h2>
              <p className="opacity-90">Op basis van jouw antwoorden zien we serieuze kansen.</p>
           </div>
           <div className="p-8 space-y-6">
              <div className="space-y-3">
                 <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                    <div className="text-sm">
                       <span className="font-bold block text-slate-800">Passende routes gevonden</span>
                       <span className="text-slate-600">We hebben mogelijke opleidingsroutes voor je in kaart gebracht.</span>
                    </div>
                 </div>
                 <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                     <Users className="w-5 h-5 text-blue-600 mt-0.5" />
                     <div className="text-sm">
                       <span className="font-bold block text-slate-800">Persoonlijk advies</span>
                       <span className="text-slate-600">In jouw persoonlijke omgeving kan Doortje je specifieke vragen beantwoorden.</span>
                    </div>
                 </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                 <button 
                   onClick={() => onComplete(answers)}
                   className="w-full bg-rotterdam-green hover:bg-[#154a48] text-white font-bold py-4 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 group"
                 >
                   Bekijk mijn persoonlijke route
                   <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                 </button>
                 <button onClick={onCancel} className="w-full mt-3 text-slate-400 text-xs hover:text-slate-600 py-2">
                   Terug naar home
                 </button>
              </div>
           </div>
        </div>
      </div>
    );
  }

  const currentQ = questions[step];
  
  let Icon = HelpCircle;
  if (currentQ.question.includes("school")) Icon = Users;
  else if (currentQ.question.includes("functie")) Icon = Briefcase;
  else if (currentQ.question.includes("niveau") || currentQ.question.includes("opleiding")) Icon = GraduationCap;
  else if (currentQ.question.includes("bevoegdheid")) Icon = CheckCircle;


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white max-w-lg w-full rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
         <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <div className="flex items-center gap-2">
               <span className="bg-white border border-slate-200 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-slate-500">
                 {step + 1}/{questions.length}
               </span>
               <span className="text-sm font-bold text-slate-400 uppercase tracking-wider">De Onderwijs Check</span>
            </div>
            <button onClick={onCancel} className="text-slate-400 hover:text-slate-600 transition-colors">
              <X className="w-6 h-6" />
            </button>
         </div>

         <div className="p-8 flex-1 overflow-y-auto">
            <div className="text-center mb-8">
               <div className="w-12 h-12 bg-rotterdam-light text-rotterdam-green rounded-xl flex items-center justify-center mx-auto mb-4">
                 <Icon className="w-6 h-6" />
               </div>
               <h3 className="text-2xl font-serif font-bold text-slate-800">{currentQ.question}</h3>
            </div>

            <div className="space-y-3">
               {currentQ.answers.map((option, idx) => (
                 <button
                   key={option.id}
                   onClick={() => handleSelect(currentQ.question, option.title)}
                   className="w-full text-left p-4 rounded-xl border border-slate-200 hover:border-rotterdam-green hover:bg-rotterdam-light hover:text-rotterdam-green transition-all font-medium text-slate-700 flex justify-between items-center group"
                 >
                   {option.title}
                   <ChevronRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-opacity text-rotterdam-green" />
                 </button>
               ))}
            </div>
         </div>
         
         <div className="p-4 bg-slate-50 border-t border-slate-100 text-center">
            {step > 0 && (
              <button onClick={() => setStep(step - 1)} className="text-sm text-slate-500 hover:text-slate-800 font-medium">
                &larr; Vorige vraag
              </button>
            )}
         </div>
      </div>
    </div>
  );
};


// --- Module 4: BackDoorAi (Backoffice Dashboard) ---

const BackDoorAiDashboard = ({ onLogout }: { onLogout: () => void }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'hitl'>('overview');
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const stats = {
    total: MOCK_CANDIDATES.length,
    hitl: MOCK_CANDIDATES.filter(u => u.hitl).length,
    active: 3
  };

  const getPhaseCounts = () => {
    const counts: Record<string, number> = {};
    PHASE_RULES.forEach(p => counts[p.code] = 0);
    MOCK_CANDIDATES.forEach(u => {
      if (counts[u.phase] !== undefined) counts[u.phase]++;
    });
    return counts;
  };
  const phaseCounts = getPhaseCounts();

  const renderContent = () => {
    if (selectedUser) {
      return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-full flex flex-col">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
             <div className="flex items-center gap-4">
                <button onClick={() => setSelectedUser(null)} className="hover:bg-white p-2 rounded-full transition-colors border border-transparent hover:border-slate-200"><ArrowLeft className="w-5 h-5 text-slate-500" /></button>
                <div>
                   <h3 className="text-xl font-bold text-slate-800">{selectedUser.name}</h3>
                   <div className="flex items-center gap-2 text-sm text-slate-500">
                     <Mail className="w-3 h-3" /> {selectedUser.email}
                     <span className="text-slate-300">|</span>
                     <span className={`px-2 py-0.5 rounded-full text-xs font-medium uppercase ${selectedUser.hitl ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                        {selectedUser.hitl ? 'Hulp nodig' : 'Regulier'}
                     </span>
                   </div>
                </div>
             </div>
             <div className="flex gap-2">
                <button className="px-4 py-2 bg-rotterdam-green text-white rounded-lg text-sm font-bold hover:bg-[#154a48]">Stuur bericht</button>
             </div>
          </div>
          <div className="flex-1 overflow-y-auto p-6">
             <div className="grid grid-cols-3 gap-8">
                <div className="col-span-2 space-y-6">
                   <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2"><MessageSquare className="w-4 h-4" /> Recente Activiteit</h4>
                      <div className="space-y-4">
                         <div className="flex justify-end"><div className="bg-rotterdam-green text-white px-4 py-2 rounded-xl rounded-tr-none text-sm">Ik wil graag weten wat ik ga verdienen.</div></div>
                         <div className="flex justify-start"><div className="bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl rounded-tl-none text-sm">Dat hangt af van je ervaring. Heb je eerdere werkervaring die relevant is?</div></div>
                         <div className="flex justify-end"><div className="bg-rotterdam-green text-white px-4 py-2 rounded-xl rounded-tr-none text-sm">Ja, 10 jaar als manager.</div></div>
                         {selectedUser.hitl && (
                           <div className="flex items-center gap-2 justify-center my-4">
                              <div className="h-px bg-red-200 flex-1"></div>
                              <span className="text-xs text-red-500 font-bold bg-red-50 px-2 py-1 rounded-full border border-red-100">HITL Melding: {selectedUser.hitl_reason}</span>
                              <div className="h-px bg-red-200 flex-1"></div>
                           </div>
                         )}
                      </div>
                   </div>
                </div>
                <div className="col-span-1 space-y-4">
                   <div className="bg-white border border-slate-200 rounded-xl p-5">
                      <h4 className="font-bold text-slate-800 text-sm uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Profiel Data</h4>
                      <ul className="space-y-3">
                         {Object.entries(SLOT_LABELS).map(([key, label]) => (
                            <li key={key} className="text-sm">
                               <span className="block text-slate-400 text-xs mb-0.5">{label}</span>
                               <span className="text-slate-700 font-medium">{selectedUser.slots[key] || "-"}</span>
                            </li>
                         ))}
                      </ul>
                   </div>
                   <div className="bg-white border border-slate-200 rounded-xl p-5">
                      <h4 className="font-bold text-slate-800 text-sm uppercase tracking-wider mb-4 border-b border-slate-100 pb-2">Fase</h4>
                       <div className="flex items-center gap-2 text-rotterdam-green font-bold">
                          <Compass className="w-5 h-5" />
                          {PHASE_RULES.find(p => p.code === selectedUser.phase)?.title}
                       </div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      );
    }

    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
                   <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center"><Users className="w-6 h-6" /></div>
                   <div><span className="block text-2xl font-bold text-slate-800">{stats.total}</span><span className="text-sm text-slate-500">Totaal Kandidaten</span></div>
                </div>
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
                   <div className="w-12 h-12 rounded-full bg-green-50 text-green-600 flex items-center justify-center"><TrendingUp className="w-6 h-6" /></div>
                   <div><span className="block text-2xl font-bold text-slate-800">{stats.active}</span><span className="text-sm text-slate-500">Actieve Sessies</span></div>
                </div>
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
                   <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center"><AlertCircle className="w-6 h-6" /></div>
                   <div><span className="block text-2xl font-bold text-slate-800">{stats.hitl}</span><span className="text-sm text-slate-500">HITL Meldingen</span></div>
                </div>
             </div>

             <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-bold text-lg text-slate-800 mb-6">Kandidaten per Fase</h3>
                <div className="grid grid-cols-5 gap-4">
                   {PHASE_RULES.map(phase => {
                      const Icon = getPhaseIcon(phase.code);
                      return (
                      <div key={phase.code} className="text-center p-4 bg-slate-50 rounded-lg border border-slate-100 hover:border-rotterdam-green transition-colors cursor-pointer" onClick={() => setActiveTab('users')}>
                         <Icon className="w-6 h-6 mx-auto text-slate-400 mb-2" />
                         <span className="block font-bold text-2xl text-rotterdam-green">{phaseCounts[phase.code]}</span>
                         <span className="text-xs uppercase font-bold text-slate-500">{phase.title}</span>
                      </div>
                   )})}
                </div>
             </div>

             <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                   <h3 className="font-bold text-lg text-slate-800">Recente HITL Verzoeken</h3>
                   <button onClick={() => setActiveTab('hitl')} className="text-sm text-rotterdam-green font-bold hover:underline">Alles bekijken</button>
                </div>
                <div>
                   {MOCK_CANDIDATES.filter(u => u.hitl).slice(0, 3).map(user => (
                      <div key={user.id} className="p-4 border-b border-slate-100 last:border-0 hover:bg-slate-50 flex items-center justify-between">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-red-100 text-red-600 rounded-full flex items-center justify-center text-sm font-bold">{user.name.charAt(0)}</div>
                            <div>
                               <span className="block font-bold text-slate-800">{user.name}</span>
                               <span className="text-xs text-red-500">{user.hitl_reason}</span>
                            </div>
                         </div>
                         <button onClick={() => setSelectedUser(user)} className="px-3 py-1 border border-slate-200 rounded text-xs font-bold hover:bg-white">Bekijk</button>
                      </div>
                   ))}
                   {MOCK_CANDIDATES.filter(u => u.hitl).length === 0 && <div className="p-8 text-center text-slate-500 text-sm">Geen openstaande meldingen.</div>}
                </div>
             </div>
          </div>
        );
      case 'users':
      case 'hitl':
        const filteredUsers = activeTab === 'hitl' ? MOCK_CANDIDATES.filter(u => u.hitl) : MOCK_CANDIDATES;
        return (
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden h-full flex flex-col">
             <div className="p-4 border-b border-slate-100 flex gap-4 bg-slate-50">
                <div className="relative flex-1">
                   <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                   <input type="text" placeholder="Zoek op naam of email..." className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-rotterdam-green bg-white" />
                </div>
                <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-slate-50"><Filter className="w-4 h-4" /> Filter</button>
             </div>
             <div className="flex-1 overflow-y-auto">
                <table className="w-full text-left text-sm">
                   <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-200">
                      <tr>
                         <th className="px-6 py-3">Naam</th>
                         <th className="px-6 py-3">Fase</th>
                         <th className="px-6 py-3">Status</th>
                         <th className="px-6 py-3">Laatst Actief</th>
                         <th className="px-6 py-3"></th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-slate-100">
                      {filteredUsers.map(user => (
                         <tr key={user.id} className="hover:bg-slate-50 transition-colors cursor-pointer" onClick={() => setSelectedUser(user)}>
                            <td className="px-6 py-4 font-medium text-slate-800">{user.name} <br/><span className="text-xs text-slate-400 font-normal">{user.email}</span></td>
                            <td className="px-6 py-4"><span className="px-2 py-1 rounded bg-slate-100 text-slate-600 text-xs font-bold uppercase">{PHASE_RULES.find(p => p.code === user.phase)?.title}</span></td>
                            <td className="px-6 py-4">
                               {user.hitl ? 
                                 <span className="flex items-center gap-1 text-red-600 font-bold text-xs"><AlertCircle className="w-4 h-4" /> Hulp nodig</span> : 
                                 <span className="flex items-center gap-1 text-green-600 font-bold text-xs"><CheckCircle className="w-4 h-4" /> OK</span>
                               }
                            </td>
                            <td className="px-6 py-4 text-slate-500">{user.last_active}</td>
                            <td className="px-6 py-4 text-right"><Eye className="w-4 h-4 text-slate-400 hover:text-rotterdam-green" /></td>
                         </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen bg-slate-100 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col hidden md:flex">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-2 text-rotterdam-green font-bold text-xl font-serif">
            <LayoutDashboard className="w-6 h-6" /> <span>BackDoor</span>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => { setActiveTab('overview'); setSelectedUser(null); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'overview' && !selectedUser ? 'bg-rotterdam-green text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
          >
            <BarChart3 className="w-5 h-5" /> Overzicht
          </button>
          <button 
             onClick={() => { setActiveTab('users'); setSelectedUser(null); }}
             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'users' && !selectedUser ? 'bg-rotterdam-green text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
          >
            <Users className="w-5 h-5" /> Kandidaten
          </button>
          <button 
             onClick={() => { setActiveTab('hitl'); setSelectedUser(null); }}
             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'hitl' && !selectedUser ? 'bg-rotterdam-green text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
          >
            <AlertCircle className="w-5 h-5" /> HITL Meldingen
            {stats.hitl > 0 && <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full ml-auto">{stats.hitl}</span>}
          </button>
        </nav>
        <div className="p-4 border-t border-slate-800">
           <button onClick={onLogout} className="flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-white transition-colors w-full">
             <ArrowLeft className="w-5 h-5" /> Uitloggen
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden flex flex-col">
        <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-8 shadow-sm">
           <div className="flex items-center gap-4">
               <button onClick={onLogout} className="md:hidden text-slate-500"><ArrowLeft className="w-5 h-5" /></button>
               <h2 className="font-bold text-xl text-slate-800">
                 {selectedUser ? 'Kandidaat Detail' : 
                  activeTab === 'overview' ? 'Dashboard Overzicht' : 
                  activeTab === 'users' ? 'Kandidatenlijst' : 'HITL Verzoeken'}
               </h2>
           </div>
           <div className="flex items-center gap-4">
              <span className="hidden md:inline text-sm text-slate-500">Ingelogd als <strong className="text-slate-800">Backoffice</strong></span>
              <div className="w-8 h-8 bg-rotterdam-green rounded-full flex items-center justify-center text-white font-bold text-xs">BO</div>
           </div>
        </header>
        <div className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar bg-slate-100">
           {renderContent()}
        </div>
      </main>
    </div>
  );
};

// --- Chat Widget (Enhanced) ---
const ChatWidget = ({ onClose, onNavigate }: { onClose: () => void, onNavigate: (page: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: "user" | "model", text: string}[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  // Nudge State
  const [showNudge, setShowNudge] = useState(false);
  const [nudgeIndex, setNudgeIndex] = useState(0);
  const [isTypingNudge, setIsTypingNudge] = useState(false);
  const [typedNudgeText, setTypedNudgeText] = useState("");
  const [nudgeEnabled, setNudgeEnabled] = useState(true); // Toggle state
  const [isPulsing, setIsPulsing] = useState(false);
  
  const chatRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const NUDGE_MESSAGES = [
    "Overweeg je een overstap naar het onderwijs?",
    "Weet jij wat je als leraar verdient?",
    "Doe de check in 1 minuut!",
    "Zij-instromer? Ik help je op weg."
  ];

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isOpen]);

  // Nudge Logic: Show after a delay, rotate messages
  useEffect(() => {
    if (!nudgeEnabled) {
        setShowNudge(false);
        setIsPulsing(false);
        return;
    }

    // Function to trigger a brief pulse
    const triggerPulse = () => {
        setIsPulsing(true);
        setTimeout(() => setIsPulsing(false), 6000); // Pulse for 6 seconds (3 cycles)
    };

    // Initial delay before first nudge
    const initialTimer = setTimeout(() => {
        setShowNudge(true);
        triggerPulse();
    }, 3000);

    const rotationInterval = setInterval(() => {
        if (!isOpen) {
            setNudgeIndex(prev => (prev + 1) % NUDGE_MESSAGES.length);
            setShowNudge(true); // Ensure it's shown when rotating
            triggerPulse(); // Pulse only when text changes
        }
    }, 30000); // Rotate every 30 seconds

    return () => {
        clearTimeout(initialTimer);
        clearInterval(rotationInterval);
    };
  }, [isOpen, nudgeEnabled]);

  // Typewriter effect for nudge
  useEffect(() => {
      if (showNudge && !isOpen && nudgeEnabled) {
          const fullText = NUDGE_MESSAGES[nudgeIndex];
          setTypedNudgeText("");
          setIsTypingNudge(true);
          
          let i = 0;
          const typingInterval = setInterval(() => {
              setTypedNudgeText(fullText.slice(0, i + 1));
              i++;
              if (i >= fullText.length) {
                  clearInterval(typingInterval);
                  setIsTypingNudge(false);
              }
          }, 50); // Typing speed

          return () => clearInterval(typingInterval);
      }
  }, [nudgeIndex, showNudge, isOpen, nudgeEnabled]);

  const initWidgetChat = async () => {
    if (chatRef.current) return;
    try {
      const ai = initGenAI();
      chatRef.current = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: { 
          systemInstruction: getSystemInstruction('WIDGET'),
          temperature: 0.5 
        }
      });
      setMessages([{ role: "model", text: "Welkom bij DoorAi! Ik ben Doortje. Kan ik u helpen met algemene informatie over werken in het onderwijs?" }]);
    } catch (e) {
      console.error("Failed to init chat", e);
      setMessages([{ role: "model", text: "Excuses, er is een technische fout opgetreden. Controleer de configuratie." }]);
    }
  };

  const toggleWidget = () => {
    if (!isOpen) {
        initWidgetChat();
        setShowNudge(false); // Hide nudge when opening
    }
    setIsOpen(!isOpen);
  };

  const handleSend = async () => {
    if (!input.trim() || !chatRef.current) return;
    const msg = input;
    setInput("");
    setMessages(prev => [...prev, { role: "user", text: msg }]);
    setIsLoading(true);

    try {
      const response = await chatRef.current.sendMessage({ message: msg });
      setMessages(prev => [...prev, { role: "model", text: response.text || "" }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: "model", text: "Excuses, ik ben even niet bereikbaar." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end font-sans group">
      
      {/* Nudge Bubble (Only visible when chat is closed) */}
      {showNudge && !isOpen && nudgeEnabled && (
        <div className="mb-3 mr-2 animate-float origin-bottom-right transition-all duration-300">
           <div className="relative bg-white/90 backdrop-blur-md text-slate-800 text-sm font-medium py-3 px-4 rounded-2xl rounded-br-none shadow-xl border border-white/50 max-w-[200px]">
               <button 
                 onClick={(e) => { e.stopPropagation(); setShowNudge(false); }}
                 className="absolute -top-2 -left-2 bg-slate-200 text-slate-500 rounded-full p-0.5 hover:bg-slate-300 transition-colors"
               >
                   <X className="w-3 h-3" />
               </button>
               <div className="flex items-center gap-2">
                   <span className="leading-tight min-h-[1.25rem]">
                       {typedNudgeText}
                       {isTypingNudge && <span className="animate-pulse">|</span>}
                   </span>
               </div>
           </div>
        </div>
      )}

      {isOpen && (
        <div className="mb-4 w-[350px] h-[450px] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="bg-rotterdam-green p-4 flex justify-between items-center text-white">
            <div className="flex items-center gap-2">
              <div className="bg-white/20 p-1.5 rounded-lg">
                  <MessageSquare className="w-5 h-5" />
              </div>
              <div className="leading-tight">
                <span className="font-bold font-serif block text-base">Doortje</span>
                <span className="text-[10px] opacity-80 uppercase tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span> Online
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1">
                <button 
                  onClick={() => setNudgeEnabled(!nudgeEnabled)} 
                  className={`hover:bg-white/10 rounded p-1.5 transition ${!nudgeEnabled ? 'opacity-50' : ''}`}
                  title={nudgeEnabled ? "Nudges uitschakelen" : "Nudges inschakelen"}
                >
                  {nudgeEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                </button>
                <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 rounded p-1 transition">
                  <X className="w-5 h-5" />
                </button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 bg-rotterdam-light custom-scrollbar">
            {messages.map((m, i) => (
              <MessageBubble key={i} role={m.role} text={m.text} compact isThinking={false} onNavigate={onNavigate} />
            ))}
            {isLoading && <MessageBubble role="model" text="" compact isThinking={true} />}
            <div ref={scrollRef} />
          </div>

          <div className="p-3 bg-white border-t border-slate-100">
            <div className="relative">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Typ uw vraag..."
                className="w-full pl-4 pr-10 py-2.5 rounded-full border border-slate-200 bg-white text-slate-700 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none text-sm shadow-inner"
              />
              <button onClick={handleSend} disabled={isLoading} className="absolute right-2 top-2 bg-rotterdam-light text-rotterdam-green p-1 rounded-full hover:bg-rotterdam-green hover:text-white transition-all disabled:opacity-50">
                <Send className="w-4 h-4" />
              </button>
            </div>
            <div className="text-[9px] text-center text-slate-400 mt-2 flex justify-center items-center gap-1">
              <Lock className="w-2.5 h-2.5" /> Privacyvriendelijk & Veilig
            </div>
          </div>
        </div>
      )}

      <div className="relative">
          {!isOpen && (
            <button 
                onClick={(e) => { e.stopPropagation(); onClose(); }}
                className="absolute -top-3 -right-2 bg-white text-slate-400 hover:text-red-500 hover:bg-red-50 border border-slate-200 rounded-full p-1.5 shadow-sm opacity-0 group-hover:opacity-100 transition-all duration-300 z-50 scale-75 hover:scale-100"
                title="Widget verbergen"
            >
                <X className="w-4 h-4" />
            </button>
          )}
          
          <button 
            onClick={toggleWidget}
            className={`h-16 w-16 bg-rotterdam-green hover:bg-[#154a48] text-white rounded-full shadow-2xl flex items-center justify-center transition-all hover:scale-105 relative z-40 ${(!isOpen && nudgeEnabled && isPulsing) ? 'animate-sonar' : ''}`}
          >
            {isOpen ? (
                <ChevronRight className="w-7 h-7 rotate-90" /> 
            ) : (
                <>
                    <MessageCircle className="w-8 h-8 relative z-10" />
                    {/* Notification dot */}
                    {nudgeEnabled && <span className="absolute top-4 right-4 w-3 h-3 bg-red-500 border-2 border-rotterdam-green rounded-full z-20"></span>}
                </>
            )}
          </button>
      </div>
    </div>
  );
};


// --- Global Layout Component ---

const MainLayout = ({ children, onNavigate }: { children?: React.ReactNode, onNavigate: (page: string) => void }) => {
  const [showRegister, setShowRegister] = useState(false);
  const [isWidgetVisible, setIsWidgetVisible] = useState(true);

  // Dynamic branding can be handled here if we lift the region state up,
  // but for the MVP, the landing page is generic and the Studio is personalized.
  // We'll stick to generic branding here.

  return (
    <div className="min-h-screen bg-white font-sans flex flex-col">
      <nav className="border-b border-slate-200 bg-white sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex justify-between items-center">
          <div 
            className="flex items-center gap-2 cursor-pointer" 
            onClick={() => onNavigate('landing')}
          >
            <div className="bg-rotterdam-green text-white p-1.5 rounded-lg">
              <MessageSquare className="w-5 h-5" />
            </div>
            <span className="font-serif font-bold text-xl text-rotterdam-green">DoorAi</span>
            <span className="hidden sm:inline text-slate-400 mx-2">|</span>
            <span className="hidden sm:inline text-sm text-slate-500 font-medium">OnderwijsRegio Rotterdam</span>
          </div>
          <div className="flex gap-4 items-center">
            <button onClick={() => onNavigate('landing')} className="hidden md:block text-slate-600 hover:text-rotterdam-green text-sm font-medium">Home</button>
            <button onClick={() => onNavigate('agenda')} className="hidden md:block text-slate-600 hover:text-rotterdam-green text-sm font-medium">Agenda</button>
            <button onClick={() => setShowRegister(true)} className="hidden md:block text-slate-600 hover:text-rotterdam-green text-sm font-medium">Inschrijven</button>
            <button 
              onClick={() => onNavigate('login')}
              title="Gebruiker: admin / admin010&#013;Backoffice: backoffice / admin010"
              className="bg-rotterdam-green hover:bg-[#154a48] text-white px-5 py-2 rounded-full text-sm font-bold transition-colors flex items-center gap-2"
            >
              <Lock className="w-4 h-4" />
              Inloggen
            </button>
          </div>
        </div>
      </nav>
      
      <div className="flex-1">
        {children}
      </div>

      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4 text-white">
               <MessageSquare className="w-6 h-6" />
               <span className="font-serif font-bold text-xl">DoorAi</span>
            </div>
            <p className="text-sm">Hét startpunt voor jouw carrière in het onderwijs.</p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Informatie</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => onNavigate('route-zijinstroom')} className="hover:text-white">Zij-instroom</button></li>
              <li><button onClick={() => onNavigate('finance')} className="hover:text-white">Subsidies</button></li>
              <li><button onClick={() => onNavigate('agenda')} className="hover:text-white">Events</button></li>
            </ul>
          </div>
           <div>
            <h4 className="text-white font-bold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li>info@onderwijs.nl</li>
              <li>Onderwijsregio's NL</li>
              {!isWidgetVisible && (
                  <li>
                    <button 
                        onClick={() => setIsWidgetVisible(true)} 
                        className="text-rotterdam-green font-bold hover:underline flex items-center gap-2 mt-4 text-xs bg-slate-800 px-3 py-2 rounded-lg transition-colors"
                    >
                        <MessageSquare className="w-3 h-3" /> Chat met Doortje
                    </button>
                  </li>
              )}
            </ul>
          </div>
           <div>
            <h4 className="text-white font-bold mb-4">Privacy</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white">Privacyverklaring</a></li>
              <li><a href="#" className="hover:text-white">Cookies</a></li>
            </ul>
          </div>
        </div>
      </footer>
      
      {isWidgetVisible && <ChatWidget onClose={() => setIsWidgetVisible(false)} onNavigate={onNavigate} />}
      {showRegister && <RegistrationModal onClose={() => setShowRegister(false)} />}
    </div>
  );
};

// --- Page Components ---

const LandingPage = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  return (
    <>
      {/* Hero Section */}
      <div className="bg-rotterdam-light relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28 relative z-10">
          <div className="max-w-2xl">
            <span className="bg-white text-rotterdam-green px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-4 inline-block shadow-sm">
              Start jouw reis in het onderwijs
            </span>
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-slate-800 leading-tight mb-6">
              Je toekomst in het onderwijs begint hier.
            </h1>
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              Rotterdam zoekt talent. Of je nu zij-instromer bent, deeltijdstudent of carrièreswitcher: wij gidsen je persoonlijk naar de klas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
               <button 
                 onClick={() => document.getElementById('routes')?.scrollIntoView({ behavior: 'smooth'})}
                 className="bg-rotterdam-green text-white px-8 py-4 rounded-xl font-bold hover:bg-[#154a48] transition-all shadow-lg flex items-center justify-center gap-2"
               >
                 Bekijk de routes <ArrowRight className="w-5 h-5" />
               </button>
               <button 
                 onClick={() => onNavigate('check')}
                 className="bg-white text-rotterdam-green border border-slate-200 px-8 py-4 rounded-xl font-bold hover:bg-slate-50 transition-all shadow-sm flex items-center justify-center gap-2"
               >
                 <BookOpen className="w-5 h-5" />
                 Doe de check
               </button>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-1/3 h-full bg-rotterdam-accent opacity-20 transform -skew-x-12 translate-x-20"></div>
        <div className="absolute bottom-0 left-10 w-64 h-64 bg-yellow-400 rounded-full mix-blend-multiply filter blur-3xl opacity-10"></div>
      </div>

      {/* Routes Section */}
      <div id="routes" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-serif font-bold text-slate-800 mb-4">Kies jouw route naar de klas</h2>
            <p className="text-slate-500 max-w-2xl mx-auto">
              Er is geen standaardroute naar het leraarschap. Jouw achtergrond bepaalt je startpunt. Bekijk hieronder welke weg het beste bij jouw situatie past.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div onClick={() => onNavigate('route-zijinstroom')} className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100 hover:border-rotterdam-green transition-all group cursor-pointer">
              <div className="w-12 h-12 bg-teal-100 text-rotterdam-green rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Briefcase className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Zij-instroom in Beroep</h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Heb je al een hbo- of wo-diploma? Sta direct betaald voor de klas en haal je bevoegdheid 'on the job' binnen twee jaar.
              </p>
              <span className="text-rotterdam-green font-bold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">Lees meer <ArrowRight className="w-4 h-4" /></span>
            </div>

            <div onClick={() => onNavigate('route-deeltijd')} className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100 hover:border-rotterdam-green transition-all group cursor-pointer">
              <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <GraduationCap className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Deeltijd Opleiding</h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Combineer je huidige baan of gezin met een studie. Je leert de theorie op de opleiding en brengt dit direct in de praktijk tijdens stages.
              </p>
              <span className="text-rotterdam-green font-bold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">Lees meer <ArrowRight className="w-4 h-4" /></span>
            </div>

             <div onClick={() => onNavigate('route-pdg')} className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100 hover:border-rotterdam-green transition-all group cursor-pointer">
              <div className="w-12 h-12 bg-purple-100 text-purple-700 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">MBO & Instructeur</h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Deel jouw vakmanschap met de volgende generatie. Haal je pedagogisch-didactisch getuigschrift (PDG) en word docent of instructeur in het mbo.
              </p>
              <span className="text-rotterdam-green font-bold text-sm flex items-center gap-1 group-hover:gap-2 transition-all">Lees meer <ArrowRight className="w-4 h-4" /></span>
            </div>
          </div>
        </div>
      </div>

      {/* Info & Agenda Preview */}
      <div className="bg-slate-50 py-20 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row gap-12 items-center">
           <div className="flex-1">
             <h2 className="text-3xl font-serif font-bold text-slate-800 mb-6">Financiële mogelijkheden</h2>
             <p className="text-slate-600 mb-6 leading-relaxed">
               Een overstap maken is een investering, maar je staat er niet alleen voor. Ontdek welke subsidies, tegemoetkomingen en salarisafspraken er gelden voor jouw situatie.
             </p>
             <button onClick={() => onNavigate('finance')} className="text-rotterdam-green font-bold flex items-center gap-2 hover:gap-3 transition-all">
                Bekijk alle subsidies <ArrowRight className="w-4 h-4" />
             </button>
           </div>
           <div className="flex-1 bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
              <h3 className="text-xl font-bold text-slate-800 mb-4">Agenda</h3>
              <ul className="space-y-4">
                 {AGENDA_ITEMS.slice(0, 3).map(item => (
                   <li key={item.id} className="flex gap-4 border-b border-slate-100 pb-4 last:border-0">
                     <div className="bg-rotterdam-light text-rotterdam-green rounded-lg p-3 text-center min-w-[60px]">
                       <span className="block text-xl font-bold">{item.date}</span>
                       <span className="text-xs uppercase font-bold">{item.month}</span>
                     </div>
                     <div>
                       <h4 className="font-bold text-slate-800">{item.title}</h4>
                       <p className="text-sm text-slate-500">Locatie: {item.loc} <br/>Tijd: {item.time}</p>
                     </div>
                   </li>
                 ))}
              </ul>
              <button 
                onClick={() => onNavigate('agenda')}
                className="w-full mt-6 text-rotterdam-green font-bold border border-rotterdam-green rounded-xl py-3 hover:bg-rotterdam-green hover:text-white transition-colors"
              >
                Bekijk volledige agenda
              </button>
           </div>
        </div>
      </div>
    </>
  );
};

const ContentPage = ({ title, subtitle, icon: Icon, children, questions, onNavigate }: any) => {
  return (
    <div className="bg-white min-h-screen">
      <div className="bg-rotterdam-light py-12 md:py-20 border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 text-center">
           {Icon && <div className="mx-auto w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-sm text-rotterdam-green mb-6"><Icon className="w-8 h-8" /></div>}
           <h1 className="text-3xl md:text-5xl font-serif font-bold text-slate-800 mb-4">{title}</h1>
           <p className="text-lg text-slate-600 max-w-2xl mx-auto">{subtitle}</p>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto px-4 py-12 grid md:grid-cols-3 gap-12">
        <div className="md:col-span-2 space-y-8">
           {children}
        </div>
        
        <div className="md:col-span-1">
           <div className="bg-white border border-slate-200 rounded-2xl p-6 sticky top-24 shadow-sm">
             <h4 className="font-bold text-slate-800 mb-4">Direct aan de slag</h4>
             <p className="text-sm text-slate-500 mb-6">Heb je vragen over deze route of wil je weten wat jouw mogelijkheden zijn?</p>
             <button onClick={() => onNavigate('login')} className="w-full bg-rotterdam-green text-white font-bold py-3 rounded-xl hover:bg-[#154a48] transition-colors mb-3 flex items-center justify-center gap-2">
               <BookOpen className="w-4 h-4" /> Start de check
             </button>
             <button onClick={() => onNavigate('contact')} className="w-full bg-white border border-slate-200 text-slate-600 font-bold py-3 rounded-xl hover:bg-slate-50 transition-colors">
               Contact opnemen
             </button>
           </div>
        </div>
      </div>
    </div>
  );
};

// --- Specific Views ---

const AgendaPage = ({ onNavigate }: any) => (
  <ContentPage 
    title="Agenda" 
    subtitle="Ontmoet scholen, bezoek open dagen of volg een webinar." 
    icon={Calendar}
    onNavigate={onNavigate}
  >
    <div className="space-y-6">
      {AGENDA_ITEMS.map(item => (
        <div key={item.id} className="flex flex-col md:flex-row gap-6 bg-white border border-slate-200 p-6 rounded-2xl hover:border-rotterdam-green transition-all">
           <div className="flex items-center gap-4 md:w-48 shrink-0">
              <div className="bg-rotterdam-light text-rotterdam-green rounded-xl p-4 text-center min-w-[80px]">
                 <span className="block text-2xl font-bold">{item.date}</span>
                 <span className="text-sm uppercase font-bold tracking-wider">{item.month}</span>
              </div>
              <div>
                <span className={`text-[10px] uppercase font-bold px-2 py-1 rounded ${item.type === 'Online' ? 'bg-blue-50 text-blue-600' : 'bg-green-50 text-green-600'}`}>{item.type}</span>
              </div>
           </div>
           <div className="flex-1">
              <h3 className="text-xl font-bold text-slate-800 mb-2">{item.title}</h3>
              <div className="flex flex-col sm:flex-row gap-4 text-sm text-slate-500">
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {item.loc}</span>
                <span className="flex items-center gap-1"><CheckCircle className="w-4 h-4" /> {item.time}</span>
              </div>
              <p className="mt-4 text-slate-600 text-sm">Leer meer over de mogelijkheden en stel direct je vragen aan experts uit de regio.</p>
           </div>
           <div className="flex items-center">
             <a 
               href={item.link}
               target="_blank" 
               rel="noopener noreferrer"
               className="px-6 py-2 border border-slate-200 rounded-lg text-sm font-bold hover:bg-rotterdam-green hover:text-white transition-colors cursor-pointer"
             >
                Aanmelden
             </a>
           </div>
        </div>
      ))}
      <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 flex gap-4 text-blue-800">
        <Info className="w-6 h-6 shrink-0" />
        <p className="text-sm">Er zijn momenteel geen andere evenementen gepland. Houd deze pagina in de gaten voor updates.</p>
      </div>
    </div>
  </ContentPage>
);

const RouteZijinstroomPage = ({ onNavigate }: any) => {
    const routeInfo = ROUTE_STEPS_DATA.find(s => s.slug === 'ulo-zib');
    return (
      <ContentPage 
        title={routeInfo ? routeInfo.short_title : "Zij-instroom in Beroep"} 
        subtitle={routeInfo ? routeInfo.long_title : "Direct voor de klas met salaris terwijl je je bevoegdheid haalt."}
        icon={Briefcase}
        onNavigate={onNavigate}
      >
        <div className="prose prose-slate max-w-none">
          <p className="lead text-lg text-slate-700">
            {routeInfo ? routeInfo.description : "Het traject 'zij-instroom in het beroep' (zib) is een bijzonder opleidingstraject tot een bevoegdheid."}
          </p>
          <h3>Hoe werkt het?</h3>
          <p>
            Je solliciteert bij een schoolbestuur. Als zij enthousiast zijn, doe je een geschiktheidsonderzoek (assessment). Als je dit haalt, kun je direct aan de slag. Je volgt daarnaast een opleiding op maat die maximaal 2 jaar duurt.
          </p>
          <ul className="space-y-2 list-none pl-0">
            <li className="flex gap-2"><Check className="w-5 h-5 text-green-500 shrink-0" /> Direct salaris en aanstelling bij de school.</li>
            <li className="flex gap-2"><Check className="w-5 h-5 text-green-500 shrink-0" /> Opleiding wordt vaak vergoed.</li>
            <li className="flex gap-2"><Check className="w-5 h-5 text-green-500 shrink-0" /> Intensieve begeleiding op de werkplek.</li>
          </ul>
          <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 text-sm text-yellow-800 mt-6">
            <strong>Let op:</strong> Dit is een pittig traject omdat je werken en leren combineert. Een goede voorbereiding is essentieel.
          </div>
        </div>
      </ContentPage>
    );
};

const FinancePage = ({ onNavigate }: any) => (
  <ContentPage 
    title="Financiën & Subsidies" 
    subtitle="Kosten, salaris en regelingen voor jouw overstap." 
    icon={Euro}
    onNavigate={onNavigate}
  >
    <div className="grid gap-6">
      <div className="bg-white border border-slate-200 p-6 rounded-2xl">
        <h3 className="font-bold text-lg text-slate-800 mb-2">Subsidieregeling Zij-instroom</h3>
        <p className="text-sm text-slate-600 mb-4">
          Schoolbesturen kunnen een subsidie aanvragen (vaak €20.000 - €25.000) om jouw opleiding en begeleiding te financieren. Hierdoor hoef je de studiekosten vaak niet zelf te betalen.
        </p>
      </div>
      <div className="bg-white border border-slate-200 p-6 rounded-2xl">
        <h3 className="font-bold text-lg text-slate-800 mb-2">Lerarenbeurs</h3>
        <p className="text-sm text-slate-600 mb-4">
          Ben je al bevoegd leraar en wil je een master volgen of je specialiseren? Dan is er de lerarenbeurs voor studiekosten en studieverlof.
        </p>
      </div>
      <div className="bg-white border border-slate-200 p-6 rounded-2xl">
        <h3 className="font-bold text-lg text-slate-800 mb-2">Salaris</h3>
        <p className="text-sm text-slate-600 mb-4">
          Als zij-instromer ontvang je direct salaris. De hoogte is afhankelijk van je ervaring en de CAO (PO, VO of MBO). Er wordt vaak gekeken naar je eerdere werkervaring voor de inschaling.
        </p>
      </div>
    </div>
  </ContentPage>
);

const ContactPage = ({ onNavigate }: any) => (
  <ContentPage title="Contact" subtitle="Wij helpen je graag verder." icon={MessageSquare} onNavigate={onNavigate}>
    <div className="grid md:grid-cols-2 gap-8">
      <div className="bg-white border border-slate-200 p-8 rounded-2xl text-center">
        <Phone className="w-8 h-8 text-rotterdam-green mx-auto mb-4" />
        <h3 className="font-bold text-slate-800">Contact</h3>
        <p className="text-slate-500 text-sm mt-2">Bereikbaar op werkdagen.</p>
        <p className="text-lg font-bold text-rotterdam-green mt-2">Onderwijsregio's NL</p>
      </div>
      <div className="bg-white border border-slate-200 p-8 rounded-2xl text-center">
        <Mail className="w-8 h-8 text-rotterdam-green mx-auto mb-4" />
        <h3 className="font-bold text-slate-800">Email</h3>
        <p className="text-slate-500 text-sm mt-2">Stuur ons een bericht en we reageren binnen 2 werkdagen.</p>
        <p className="text-lg font-bold text-rotterdam-green mt-2">info@onderwijs.nl</p>
      </div>
    </div>
  </ContentPage>
);

// --- Module 3: Inline AI Studio (The Protected App) ---

const StudioApp = ({ onLogout, initialSlots }: { onLogout: () => void, initialSlots?: any }) => {
  const [userData, setUserData] = useState<{name: string, region: string} | null>(null);
  const [isOnboarding, setIsOnboarding] = useState(true);
  const [currentPhaseIndex, setCurrentPhaseIndex] = useState(0);
  const [messages, setMessages] = useState<Array<{role: "user" | "model", text: string}>>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [collectedSlots, setCollectedSlots] = useState<Record<string, string>>({});
  const chatSessionRef = useRef<any>(null);
  const scrollEndRef = useRef<HTMLDivElement>(null);
  const [regionData, setRegionData] = useState<RegionData | undefined>(undefined);

  useEffect(() => { scrollEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, isLoading]);

  useEffect(() => {
    if (initialSlots) {
       setCollectedSlots(prev => ({ ...prev, ...initialSlots }));
       // Skip onboarding if we came from check, assume Rotterdam for now if not set
       handleOnboardingComplete("Bezoeker", "onderwijsloket-rotterdam", true); 
    }
  }, [initialSlots]);

  const handleOnboardingComplete = (name: string, regionSlug: string, fromCheck = false) => {
    // Find region data
    const rData = ALL_REGIONS_DATA.find(r => r.slug === regionSlug || r.title === regionSlug);
    setRegionData(rData);
    
    setUserData({ name, region: rData ? rData.title : regionSlug });
    setIsOnboarding(false);
    setCollectedSlots(prev => ({ ...prev, region_preference: rData ? rData.title : regionSlug }));
    startChat(name, rData ? rData.title : regionSlug, fromCheck);
  };

  const startChat = async (name: string, region: string, fromCheck: boolean) => {
    try {
        const ai = initGenAI();
        const currentPhase = PHASE_RULES[0];
        chatSessionRef.current = ai.chats.create({
            model: "gemini-3-flash-preview",
            config: {
            systemInstruction: getSystemInstruction('STUDIO', {name, region}, currentPhase.code, {region_preference: region}),
            temperature: 0.5,
            tools: [{functionDeclarations: [journeyTool]}],
            }
        });
        setIsLoading(true);
        
        let initMsg = `START_SESSION: Gebruiker ${name}, Regio ${region}. Huidige fase: ${currentPhase.title}. Stel jezelf voor als Doortje.`;
        
        if (fromCheck && initialSlots) {
            initMsg += ` De gebruiker heeft al een check gedaan. Bekende info: ${JSON.stringify(initialSlots)}. Verwerk dit in je introductie en stel direct een relevante vervolgvraag.`;
        }

        const response = await chatSessionRef.current.sendMessage({ message: initMsg });
        handleModelResponse(response);
    } catch (error) {
        console.error("Studio chat init error", error);
        setMessages([{ role: "model", text: "Er is een technische fout opgetreden bij het starten van de sessie." }]);
        setIsLoading(false);
    }
  };

  // Phase transition logic based on slot completion rules
  const canSwitchToPhase = (index: number) => {
    // Can always go back
    if (index <= currentPhaseIndex) return true;
    
    // To go forward, check if *previous* phases are complete
    // Strictly enforcing that current phase slots must be filled before moving to next
    const currentPhaseConfig = PHASE_RULES[currentPhaseIndex];
    const missing = currentPhaseConfig.required_slots.filter(s => !collectedSlots[s]);
    
    return missing.length === 0;
  };

  const handlePhaseChange = async (index: number) => {
    if (index === currentPhaseIndex) return;
    
    if (!canSwitchToPhase(index)) {
        // Find missing slots for current phase
        const currentPhaseConfig = PHASE_RULES[currentPhaseIndex];
        const missing = currentPhaseConfig.required_slots.filter(s => !collectedSlots[s]);
        const missingLabels = missing.map(s => SLOT_LABELS[s] || s).join(", ");
        
        alert(`Je kunt nog niet naar de volgende fase. We missen nog informatie over: ${missingLabels}.`);
        return;
    }

    setCurrentPhaseIndex(index);
    const newPhase = PHASE_RULES[index];
    setIsLoading(true);
    
    // Update system instruction with new phase context
    if(chatSessionRef.current) {
        // Note: Gemini API might not support updating system instruction mid-chat easily without a new chat session or a clear context switch prompt.
        // We simulate context switch by sending a system update message.
    }

    try {
      const response = await chatSessionRef.current.sendMessage({ 
        message: `[SYSTEEM UPDATE]: Gebruiker navigeert handmatig naar fase: '${newPhase.title}'. Check of alle slots voor de vorige fase gevuld zijn. Zo niet, stuur ze terug. Zo ja, verwelkom in de nieuwe fase.` 
      });
      handleModelResponse(response);
    } catch (e) { setIsLoading(false); } 
  };

  const handleSend = async () => {
    if (!input.trim() || !chatSessionRef.current) return;
    const userMsg = input; setInput("");
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setIsLoading(true);

    // RAG Step: Find relevant knowledge based on user query
    const ragContext = findRelevantKnowledge(userMsg);
    
    try {
      // We prepend the RAG context to the user message for the model to see, 
      // but we don't show this hidden context in the UI (User sees only their message)
      const messageWithContext = ragContext 
        ? `[CONTEXT_INJECTIE: ${ragContext}]\n\nGEBRUIKERS VRAAG: ${userMsg}`
        : userMsg;

      const response = await chatSessionRef.current.sendMessage({ message: messageWithContext });
      await handleModelResponse(response);
    } catch (e) {
      setMessages(prev => [...prev, { role: "model", text: "Excuus, ik kon dat niet verwerken." }]);
      setIsLoading(false);
    } 
  };

  const handleModelResponse = async (response: any) => {
    let text = response.text || "";
    if (response.functionCalls && response.functionCalls.length > 0) {
        const call = response.functionCalls[0];
        if (call.name === "updateJourneyState") {
            const args = call.args;
            
            // 1. Update Slots
            if (args.extracted_slots) {
                setCollectedSlots(prev => ({...prev, ...args.extracted_slots}));
            }

            // 2. Handle Phase Transition Suggestion
            if (args.suggest_phase_transition) {
                const nextPhaseIdx = PHASE_RULES.findIndex(p => p.code === args.suggest_phase_transition);
                
                // Check enforcement logic before following AI suggestion
                if (nextPhaseIdx !== -1 && nextPhaseIdx > currentPhaseIndex) {
                     const currentPhaseConfig = PHASE_RULES[currentPhaseIndex];
                     // Re-verify if we actually have the data (including what was just extracted)
                     const currentSlots = {...collectedSlots, ...args.extracted_slots};
                     const missing = currentPhaseConfig.required_slots.filter(s => !currentSlots[s]);
                     
                     if (missing.length === 0) {
                        setCurrentPhaseIndex(nextPhaseIdx);
                        // Inform model transition succeeded
                        const nextResponse = await chatSessionRef.current.sendMessage([{ functionResponse: { name: "updateJourneyState", response: { status: "success", phase_updated_to: args.suggest_phase_transition } } }]);
                        text = nextResponse.text;
                     } else {
                        // Reject transition
                        const nextResponse = await chatSessionRef.current.sendMessage([{ functionResponse: { name: "updateJourneyState", response: { status: "error", message: `Missing required slots for current phase: ${missing.join(', ')}` } } }]);
                        text = nextResponse.text;
                     }
                } else if (nextPhaseIdx !== -1 && nextPhaseIdx !== currentPhaseIndex) {
                    // Moving backwards is always allowed
                    setCurrentPhaseIndex(nextPhaseIdx);
                    const nextResponse = await chatSessionRef.current.sendMessage([{ functionResponse: { name: "updateJourneyState", response: { status: "success", phase_updated_to: args.suggest_phase_transition } } }]);
                    text = nextResponse.text;
                } else {
                     const nextResponse = await chatSessionRef.current.sendMessage([{ functionResponse: { name: "updateJourneyState", response: { status: "success", info: "slots_updated" } } }]);
                     text = nextResponse.text;
                }
            } else {
                const nextResponse = await chatSessionRef.current.sendMessage([{ functionResponse: { name: "updateJourneyState", response: { status: "success", info: "slots_updated" } } }]);
                text = nextResponse.text;
            }
        }
    }
    setMessages(prev => [...prev, { role: "model", text: text || "" }]);
    setIsLoading(false);
  };

  if (isOnboarding) return <Onboarding onComplete={handleOnboardingComplete} />;

  // Get map center from region data, or fallback
  const mapCenter = regionData?.area?.area_center 
    ? [regionData.area.area_center.coordinates[1], regionData.area.area_center.coordinates[0]] as [number, number]
    : getLeafletCenter(userData?.region || "");
    
  const mapPoly = regionData?.slug ? getLeafletPolygon(regionData.slug) as [number, number][] : [];

  return (
    <div className="flex h-screen bg-rotterdam-light overflow-hidden font-sans">
      <aside className="w-80 bg-white border-r border-slate-200 flex flex-col shadow-sm z-20 hidden md:flex">
        <div className="p-6 border-b border-slate-100 flex flex-col gap-1">
          <div className="flex justify-between items-center">
            <h2 className="font-serif font-bold text-rotterdam-green text-2xl flex items-center gap-2">
              <MessageSquare className="w-7 h-7" /> {userData?.region || 'DoorAi'}
            </h2>
            <button onClick={onLogout} className="text-xs text-slate-400 hover:text-red-500">Uitloggen</button>
          </div>
          <span className="text-xs text-slate-500 font-medium ml-9 uppercase tracking-wider">Mijn Omgeving</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          <div className="relative mt-2">
            <div className="absolute left-5 top-5 bottom-5 w-0.5 bg-slate-200 -z-10"></div>
            {PHASE_RULES.map((phase, idx) => {
              const isActive = idx === currentPhaseIndex;
              const isPast = idx < currentPhaseIndex;
              const Icon = getPhaseIcon(phase.code);
              const isLocked = !canSwitchToPhase(idx);

              return (
                <button 
                  key={phase.code} 
                  onClick={() => handlePhaseChange(idx)} 
                  disabled={isLocked}
                  className={`w-full text-left group flex items-start gap-4 p-3 rounded-xl transition-all duration-200 mb-1 ${isActive ? "bg-rotterdam-light ring-1 ring-rotterdam-accent" : "hover:bg-slate-50"} ${isLocked ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  <div className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-colors shadow-sm ${isActive ? "bg-rotterdam-green text-white" : isPast ? "bg-rotterdam-accent text-rotterdam-green" : "bg-white border-2 border-slate-200 text-slate-400"}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="pt-0.5">
                    <span className={`block text-sm font-bold ${isActive ? "text-rotterdam-green" : "text-slate-600"}`}>{phase.title}</span>
                    <span className="text-xs text-slate-500 leading-tight block mt-0.5 opacity-80">{phase.description}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </aside>
      <main className="flex-1 flex flex-col relative min-w-0 bg-white shadow-xl md:shadow-none">
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center shadow-sm z-10 h-20">
          <div>
             <div className="flex items-center gap-2 mb-1">
               <span className="bg-rotterdam-light text-rotterdam-green text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wide">Fase {currentPhaseIndex + 1}/{PHASE_RULES.length}</span>
               <div className="flex items-center gap-1 text-xs text-slate-400"><MapPin className="w-3 h-3" /> {userData?.region}</div>
             </div>
             <h3 className="text-lg font-serif font-bold text-slate-800 flex items-center gap-2">{PHASE_RULES[currentPhaseIndex].title}</h3>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-rotterdam-light custom-scrollbar">
          <div className="max-w-3xl mx-auto">
             {messages.map((msg, idx) => (<MessageBubble key={idx} role={msg.role} text={msg.text} />))}
             {isLoading && <MessageBubble role="model" text="" isThinking={true} />}
             <div ref={scrollEndRef} className="h-4" />
          </div>
        </div>
        <div className="p-4 sm:p-6 bg-white border-t border-slate-200 z-20">
          <div className="max-w-3xl mx-auto relative">
            <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())} placeholder="Typ hier uw bericht aan Doortje..." className="w-full pl-5 pr-14 py-4 rounded-xl bg-slate-50 border border-slate-200 focus:border-rotterdam-green focus:ring-1 focus:ring-rotterdam-green outline-none resize-none shadow-inner text-slate-700 placeholder:text-slate-400 text-sm" rows={1} style={{ minHeight: "60px", maxHeight: "150px" }} />
            <button onClick={handleSend} disabled={isLoading || !input.trim()} className="absolute right-3 top-3 bg-rotterdam-green hover:bg-[#154a48] disabled:opacity-50 disabled:hover:bg-rotterdam-green text-white p-2.5 rounded-lg transition-all shadow-sm"><Send className="w-5 h-5" /></button>
          </div>
        </div>
      </main>
      <aside className="w-80 hidden lg:block z-10 shadow-lg border-l border-slate-200 bg-white flex flex-col">
         {/* Map Section */}
         <div className="h-48 w-full relative z-0">
             <MapContainer 
                center={mapCenter} 
                zoom={10} 
                scrollWheelZoom={false} 
                style={{ height: "100%", width: "100%" }}
                zoomControl={false}
             >
                <MapUpdater center={mapCenter} zoom={9} />
                <TileLayer
                  attribution='&copy; OpenStreetMap'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {mapPoly.length > 0 && (
                     <Polygon 
                      pathOptions={{ color: '#1F5C59', fillColor: '#1F5C59', fillOpacity: 0.1, weight: 2 }} 
                      positions={mapPoly} 
                    />
                )}
             </MapContainer>
             <div className="absolute bottom-2 left-2 bg-white/90 px-2 py-1 rounded text-[10px] shadow font-bold text-slate-600 z-[400]">
                 {regionData?.title || 'Nederland'}
             </div>
         </div>
         <QuickFactsPanel collectedSlots={collectedSlots} region={userData?.region || ""} currentPhaseIndex={currentPhaseIndex} />
      </aside>
    </div>
  );
};

const QuickFactsPanel = ({ collectedSlots, region, currentPhaseIndex }: { collectedSlots: Record<string, string>, region: string, currentPhaseIndex: number }) => {
    // Determine missing slots for the CURRENT phase
    const currentPhaseConfig = PHASE_RULES[currentPhaseIndex];
    const missing = currentPhaseConfig.required_slots.filter(s => !collectedSlots[s]);
    
    return (
      <div className="flex-1 bg-white flex flex-col overflow-hidden">
        <div className="p-6 border-b border-slate-100 bg-rotterdam-light">
          <div className="flex items-center gap-2 text-rotterdam-green"><Lightbulb className="w-5 h-5" /><h3 className="font-serif font-bold text-lg">Status Update</h3></div>
        </div>
        <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
          
          {/* Missing Actions Section */}
          {missing.length > 0 && (
              <div className="bg-orange-50 border border-orange-100 rounded-lg p-4 mb-4">
                  <h4 className="text-xs font-bold text-orange-700 uppercase tracking-wide mb-2 flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Nog nodig voor volgende fase</h4>
                  <ul className="space-y-2">
                      {missing.map(key => (
                          <li key={key} className="text-xs text-orange-800 flex items-center gap-2">
                              <div className="w-1.5 h-1.5 rounded-full bg-orange-400"></div>
                              {SLOT_LABELS[key] || key}
                          </li>
                      ))}
                  </ul>
              </div>
          )}

          <div className="space-y-4">
            <h4 className="font-semibold text-rotterdam-green text-xs uppercase tracking-wider border-b border-slate-100 pb-2">Bekende Informatie</h4>
            <ul className="space-y-3">
              {Object.entries(SLOT_LABELS).map(([key, label]) => {
                  const isFilled = !!collectedSlots[key];
                  return (
                    <li key={key} className={`flex gap-3 text-sm leading-relaxed group ${isFilled ? 'text-rotterdam-green font-medium' : 'text-slate-400'}`}>
                      <div className={`mt-0.5 w-4 h-4 rounded-full flex items-center justify-center border ${isFilled ? 'bg-rotterdam-light border-rotterdam-green' : 'border-slate-200'}`}>{isFilled && <Check className="w-3 h-3" />}</div>
                      <div className="flex-1"><span className="block text-xs">{label}</span>{isFilled && <span className="block text-xs text-slate-600 mt-0.5 font-normal">{collectedSlots[key]}</span>}</div>
                    </li>
                  );
              })}
            </ul>
          </div>
        </div>
      </div>
    );
};

const Onboarding = ({ onComplete }: any) => {
  const [name, setName] = useState("");
  // Sort regions alphabetically
  const sortedRegions = [...ALL_REGIONS_DATA].sort((a, b) => a.title.localeCompare(b.title));
  const [regionSlug, setRegionSlug] = useState(sortedRegions[0].slug);

  return (
    <div className="min-h-screen bg-rotterdam-light flex flex-col items-center justify-center p-4 font-sans animate-in zoom-in-95 duration-300">
      <div className="bg-white max-w-md w-full rounded-2xl shadow-xl overflow-hidden border border-slate-100">
        <div className="bg-rotterdam-green p-8 text-white text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-yellow-400"></div>
          <MessageSquare className="w-12 h-12 mx-auto mb-4 text-white opacity-90" />
          <h1 className="text-3xl font-serif font-bold mb-2">DoorAi</h1>
          <p className="text-rotterdam-accent opacity-90 text-sm">Configureer uw profiel</p>
        </div>
        <div className="p-8 space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Hoe mogen we u noemen?</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-rotterdam-green focus:ring-2 focus:ring-rotterdam-accent outline-none transition-all text-slate-800 bg-white" placeholder="Uw voornaam" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">In welke regio zoekt u werk?</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-3.5 w-5 h-5 text-slate-400" />
              <select value={regionSlug} onChange={(e) => setRegionSlug(e.target.value)} className="w-full pl-10 pr-4 py-3 rounded-lg border border-slate-200 focus:border-rotterdam-green focus:ring-2 focus:ring-rotterdam-accent outline-none appearance-none bg-white transition-all text-slate-800 text-sm">
                {sortedRegions.map(r => <option key={r.id} value={r.slug}>{r.title}</option>)}
              </select>
            </div>
            <p className="text-xs text-slate-400 mt-2">We passen de informatie en contactgegevens aan op basis van uw regio.</p>
          </div>
          <button onClick={() => name && onComplete(name, regionSlug)} disabled={!name} className="w-full bg-rotterdam-green hover:bg-[#154a48] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm mt-2">Start Sessie <ChevronRight className="w-5 h-5" /></button>
        </div>
      </div>
    </div>
  );
};

const LoginScreen = ({ onLogin, onBack }: { onLogin: (role: 'user' | 'admin') => void, onBack: () => void }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === "admin" && password === "admin010") {
      onLogin('user');
    } else if (email === "backoffice" && password === "admin010") {
      onLogin('admin');
    } else {
      setError("Ongeldige inloggegevens.");
    }
  };

  return (
    <div className="min-h-screen bg-rotterdam-light flex flex-col items-center justify-center p-4 font-sans animate-in zoom-in-95 duration-300">
      <div className="bg-white max-w-sm w-full rounded-2xl shadow-xl overflow-hidden border border-slate-100">
        <div className="bg-rotterdam-green p-6 text-white flex justify-between items-center">
           <div className="flex items-center gap-2">
             <Lock className="w-5 h-5" />
             <h2 className="font-serif font-bold text-xl">Inloggen</h2>
           </div>
           <button onClick={onBack} className="hover:bg-white/10 p-1 rounded transition-colors"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">E-mailadres</label>
            <input 
              type="text" 
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(""); }}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-rotterdam-green focus:ring-2 focus:ring-rotterdam-accent outline-none transition-all text-slate-800 bg-white" 
              placeholder="gebruiker of backoffice"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Wachtwoord</label>
            <input 
              type="password" 
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(""); }}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-rotterdam-green focus:ring-2 focus:ring-rotterdam-accent outline-none transition-all text-slate-800 bg-white" 
              placeholder="••••••••"
            />
          </div>
          {error && <p className="text-red-500 text-xs text-center">{error}</p>}
          <button type="submit" className="w-full bg-rotterdam-green hover:bg-[#154a48] text-white font-bold py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm">
            Verder naar Omgeving <ArrowRight className="w-4 h-4" />
          </button>
          <div className="text-center pt-2">
            <button type="button" onClick={onBack} className="text-xs text-slate-400 hover:text-rotterdam-green transition-colors">Wachtwoord vergeten?</button>
          </div>
        </form>
        <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
          <p className="text-xs text-slate-500">Nog geen account? <button type="button" className="text-rotterdam-green font-bold hover:underline">Vraag toegang aan</button></p>
        </div>
      </div>
    </div>
  );
};

// --- App Router ---

const App = () => {
  const [view, setView] = useState('landing');
  const [checkData, setCheckData] = useState(null);

  const handleCheckComplete = (data: any) => {
      setCheckData(data);
      setView('login');
  };

  const renderView = () => {
    switch(view) {
      case 'studio': return <StudioApp onLogout={() => setView('landing')} initialSlots={checkData} />;
      case 'backoffice': return <BackDoorAiDashboard onLogout={() => setView('landing')} />;
      case 'login': return <LoginScreen onLogin={(role) => setView(role === 'admin' ? 'backoffice' : 'studio')} onBack={() => setView('landing')} />;
      case 'check': return <RouteCheckWizard onComplete={handleCheckComplete} onCancel={() => setView('landing')} />;
      case 'agenda': return <MainLayout onNavigate={setView}><AgendaPage onNavigate={setView} /></MainLayout>;
      case 'route-zijinstroom': return <MainLayout onNavigate={setView}><RouteZijinstroomPage onNavigate={setView} /></MainLayout>;
      case 'route-deeltijd': return <MainLayout onNavigate={setView}><ContentPage title="Deeltijd Opleiding" subtitle="Studeren naast je werk of stage." icon={GraduationCap} questions={[]} onNavigate={setView}><div className="prose max-w-none text-slate-600"><p>{ROUTE_STEPS_DATA.find(s => s.slug === 'p-hbo-b')?.description || "Informatie over deeltijd."}</p></div></ContentPage></MainLayout>;
      case 'route-pdg': return <MainLayout onNavigate={setView}><ContentPage title="MBO & Instructeur (PDG)" subtitle="Jouw vakmanschap voor de klas." icon={Users} questions={[]} onNavigate={setView}><div className="prose max-w-none text-slate-600"><p>{ROUTE_STEPS_DATA.find(s => s.slug === 'pdg-a')?.description || "Informatie over PDG."}</p></div></ContentPage></MainLayout>;
      case 'finance': return <MainLayout onNavigate={setView}><FinancePage onNavigate={setView} /></MainLayout>;
      case 'contact': return <MainLayout onNavigate={setView}><ContactPage onNavigate={setView} /></MainLayout>;
      default: return <MainLayout onNavigate={setView}><LandingPage onNavigate={setView} /></MainLayout>;
    }
  };

  return (
    <ErrorBoundary>
      {renderView()}
    </ErrorBoundary>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);